<?php

return [
    'debug' => false,

    'config_cache_enabled' => true,
];
