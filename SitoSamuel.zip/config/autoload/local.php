<?php

return [
    'debug' => true,

    'config_cache_enabled' => false,
];
